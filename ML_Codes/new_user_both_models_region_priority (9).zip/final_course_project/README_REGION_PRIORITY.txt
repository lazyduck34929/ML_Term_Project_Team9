지역 우선 추천 버전

실행:
python -m pip install numpy pandas scikit-learn scikit-surprise
python new_user_both_models.py --data-root .

유지되는 기능:
- 콘텐츠 기반 Ridge + 협업 필터링 KNN/SVD++
- Validation 기반 결합 가중치 선택, Test 평가
- 4개 장소, 구간별 40분 이하, 총 75분 이하

새로운 지역 탐색 단계:
1. 선택 자치구 내 4개 장소로 구성된 유효 코스
2. 없으면 선택 자치구와 중심점 거리가 가까운 5개 자치구를 허용한 코스
3. 그래도 없으면 서울 전체 코스
각 단계에서 결합 예측 평점 합계가 가장 높은 코스를 선택합니다.

참고: 가까운 5개 구는 좌표 중심점의 직선거리 순서로 선택합니다.
행정경계상 실제 인접 여부와 같지 않을 수 있습니다.
도보 이동 시간은 실제 길찾기 값이 아닌 추정값입니다.
