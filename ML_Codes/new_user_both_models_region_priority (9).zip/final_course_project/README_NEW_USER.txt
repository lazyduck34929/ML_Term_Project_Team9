신규 사용자 취향 입력 기반 서울 데이트 코스 추천

1. 터미널에서 폴더로 이동합니다.
2. 패키지 설치: python -m pip install numpy pandas scikit-learn
3. 실행: python new_user_course.py --data-root .
4. 명소/문화/쇼핑 선호도(0~10)와 선호 서울 자치구를 입력합니다.
5. 결과: new_user_output/ranked_courses_new_user.csv, place_scores_new_user.csv

주의: 신규 사용자는 과거 평점이 없으므로 콘텐츠 기반 모델만 사용합니다.
기존 사용자 대상 콘텐츠+협업 필터링 결합 모델은 별도의 final_course_pipeline.py입니다.
도보 시간은 실제 도보 경로가 아닌 직선거리 보정 추정치입니다.
