서울 데이트 코스 최종 통합 실행

1. Python 3.11 권장
2. pip install numpy pandas scikit-learn scikit-surprise
3. python final_course_pipeline.py --data-root . --user-id U0001
4. final_course_output 폴더에서 validation_weight_search.csv, test_metrics.csv, ranked_courses_U0001.csv 확인

주의: 도보 이동 시간은 실제 길찾기 API 검증값이 아닌 직선거리 기반 추정값입니다.
