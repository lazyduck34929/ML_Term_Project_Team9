신규 사용자 입력 + 콘텐츠 기반 Ridge + 협업 필터링 KNN/SVD++ 결합

설치: python -m pip install numpy pandas scikit-learn scikit-surprise
확인: python -c "import surprise; print('OK')"
실행: python new_user_both_models.py --data-root .

입력: 명소/문화/쇼핑 선호도 (각 0~10), 서울 자치구
출력: 검증셋 최적 결합 가중치, Test 성능, 신규 사용자 4곳 추천, CSV 결과

중요: 신규 사용자에게는 평점 이력이 없어 협업 필터링은 기존 사용자 중
입력 취향과 유사한 20명의 KNN+SVD++ 예측 점수를 가중 평균한 대리 추정입니다.
유사도: 카테고리 코사인 유사도 80% + 같은 자치구 여부 20%.
이 유사도 비율은 별도 검증으로 최적화된 값이 아닙니다.
결합 가중치는 기존 가상 사용자 Validation에서 최적화된 값이며,
신규 사용자 대리 추정에 대한 독립적인 성능 보증은 아닙니다.
도보 시간은 직선거리 기반 추정값으로 실제 도보 경로 검증이 아닙니다.
